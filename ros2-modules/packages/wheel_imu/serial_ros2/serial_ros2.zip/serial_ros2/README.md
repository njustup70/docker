# Serial Communication Library
just for linux ros2


clone from http://wjwwood.github.com/serial/

API Documentation: http://wjwwood.github.com/serial/doc/1.1.0/index.html



### Install

Get the code to your ros2_workspace/src:

    git clone https://github.com/jinmenglei/serial_ros2
Build:

    ament build

